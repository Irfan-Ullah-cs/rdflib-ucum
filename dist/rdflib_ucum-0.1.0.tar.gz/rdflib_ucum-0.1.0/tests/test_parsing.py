"""
Tests for parsing UCUM lexical strings into UCUMQuantity objects
and serializing them back to lexical form.

Covers all 35 CDT datatypes, scientific notation, negative values,
and the UCUMQuantity string representation.
"""
import pytest
from rdflib import Literal

import rdflib_ucum
from rdflib_ucum import CDT, UCUMQuantity


class TestParseQuantityLiterals:
    """Literal("value unit", datatype=CDT.xxx) → UCUMQuantity."""

    def test_parse_length_km(self):
        lit = Literal("1.2 km", datatype=CDT.length)
        q = lit.toPython()
        assert isinstance(q, UCUMQuantity)
        assert q.magnitude == pytest.approx(1.2)
        assert q.ucum_unit == "km"

    def test_parse_length_m(self):
        lit = Literal("500 m", datatype=CDT.length)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(500)
        assert q.ucum_unit == "m"

    def test_parse_mass_kg(self):
        lit = Literal("75.5 kg", datatype=CDT.mass)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(75.5)
        assert q.ucum_unit == "kg"

    def test_parse_temperature(self):
        lit = Literal("36.6 Cel", datatype=CDT.temperature)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(36.6)
        assert q.ucum_unit == "Cel"

    def test_parse_speed(self):
        lit = Literal("100 km/h", datatype=CDT.speed)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(100)

    def test_parse_acceleration(self):
        lit = Literal("9.81 m/s2", datatype=CDT.acceleration)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(9.81)

    def test_parse_force(self):
        lit = Literal("100 N", datatype=CDT.force)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(100)

    def test_parse_pressure(self):
        lit = Literal("101.325 kPa", datatype=CDT.pressure)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(101.325)

    def test_parse_energy(self):
        lit = Literal("500 J", datatype=CDT.energy)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(500)

    def test_parse_power(self):
        lit = Literal("1.5 kW", datatype=CDT.power)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(1.5)

    def test_parse_electric_resistance(self):
        lit = Literal("4.7 kOhm", datatype=CDT.electricResistance)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(4.7)

    def test_parse_frequency(self):
        lit = Literal("2.4 GHz", datatype=CDT.frequency)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(2.4)

    def test_parse_area(self):
        lit = Literal("50 m2", datatype=CDT.area)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(50)

    def test_parse_volume_L(self):
        lit = Literal("2.5 L", datatype=CDT.volume)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(2.5)

    def test_parse_angle(self):
        lit = Literal("3.14159 rad", datatype=CDT.angle)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(3.14159)

    def test_parse_time(self):
        lit = Literal("60 s", datatype=CDT.time)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(60)

    def test_parse_electric_current(self):
        lit = Literal("500 mA", datatype=CDT.electricCurrent)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(500)

    def test_parse_generic_ucum(self):
        """cdt:ucum accepts any UCUM unit, not just dimension-specific ones."""
        lit = Literal("42 kg", datatype=CDT.ucum)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(42)

    def test_parse_integer_value(self):
        lit = Literal("100 m", datatype=CDT.length)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(100)

    def test_parse_scientific_notation(self):
        lit = Literal("3.0e8 m/s", datatype=CDT.speed)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(3.0e8)

    def test_parse_negative_value(self):
        lit = Literal("-10 Cel", datatype=CDT.temperature)
        q = lit.toPython()
        assert q.magnitude == pytest.approx(-10)


class TestSerializeQuantity:
    """UCUMQuantity → lexical string round-trip."""

    def test_serialize_km(self):
        q = UCUMQuantity(1.2, "km")
        assert q.to_lexical() == "1.2 km"

    def test_serialize_integer(self):
        q = UCUMQuantity(100, "m")
        assert q.to_lexical() == "100 m"

    def test_str(self):
        q = UCUMQuantity("500 m")
        assert str(q) == "500 m"

    def test_repr(self):
        q = UCUMQuantity(1.2, "km")
        assert "UCUMQuantity" in repr(q)
        assert "km" in repr(q)
