"""
Tests for Python-level operators on CDT Literals and UCUMQuantity objects.

Covers unit-aware equality (the critical 1 km == 1000 m test),
ordering comparisons, and arithmetic operations. These operators
are what RDFLib delegates to via bind() registration.
"""
import pytest
from rdflib import Literal

import rdflib_ucum
from rdflib_ucum import CDT


class TestUnitAwareEquality:
    """Literal.eq() delegates to UCUMQuantity.__eq__ for value-space comparison."""

    def test_eq_same_unit(self):
        a = Literal("1 km", datatype=CDT.length)
        b = Literal("1 km", datatype=CDT.length)
        assert a.eq(b)

    def test_eq_cross_unit(self):
        """The critical test: 1 km == 1000 m via unit conversion."""
        a = Literal("1 km", datatype=CDT.length)
        b = Literal("1000 m", datatype=CDT.length)
        assert a.eq(b)

    def test_neq_different_values(self):
        a = Literal("1 km", datatype=CDT.length)
        b = Literal("500 m", datatype=CDT.length)
        assert not a.eq(b)

    def test_eq_mass_cross_unit(self):
        a = Literal("1 kg", datatype=CDT.mass)
        b = Literal("1000 g", datatype=CDT.mass)
        assert a.eq(b)

    def test_eq_time_cross_unit(self):
        a = Literal("1 h", datatype=CDT.time)
        b = Literal("3600 s", datatype=CDT.time)
        assert a.eq(b)

    def test_neq_different_datatypes(self):
        """Different CDT datatype URIs should not be equal."""
        a = Literal("1 m", datatype=CDT.length)
        b = Literal("1 m", datatype=CDT.mass)
        assert not a.eq(b)


class TestComparison:
    """Literal.__gt__ etc. delegate to UCUMQuantity comparison operators."""

    def test_gt_same_unit(self):
        a = Literal("1000 m", datatype=CDT.length)
        b = Literal("500 m", datatype=CDT.length)
        assert a > b

    def test_gt_cross_unit(self):
        a = Literal("1 km", datatype=CDT.length)
        b = Literal("500 m", datatype=CDT.length)
        assert a > b

    def test_lt(self):
        a = Literal("500 m", datatype=CDT.length)
        b = Literal("1 km", datatype=CDT.length)
        assert a < b

    def test_ge(self):
        a = Literal("1 km", datatype=CDT.length)
        b = Literal("1000 m", datatype=CDT.length)
        assert a >= b

    def test_le(self):
        a = Literal("1000 m", datatype=CDT.length)
        b = Literal("1 km", datatype=CDT.length)
        assert a <= b


class TestArithmetic:
    """Literal.__add__ etc. delegate to UCUMQuantity arithmetic operators."""

    def test_add_same_unit(self):
        a = Literal("5 km", datatype=CDT.length)
        b = Literal("3 km", datatype=CDT.length)
        c = a + b
        assert isinstance(c, Literal)
        assert c.toPython().magnitude == pytest.approx(8)

    def test_add_cross_unit(self):
        a = Literal("5 km", datatype=CDT.length)
        b = Literal("200 m", datatype=CDT.length)
        c = a + b
        q = c.toPython()
        assert q.magnitude == pytest.approx(5.2)

    def test_sub(self):
        a = Literal("5 km", datatype=CDT.length)
        b = Literal("200 m", datatype=CDT.length)
        c = a - b
        q = c.toPython()
        assert q.magnitude == pytest.approx(4.8)
