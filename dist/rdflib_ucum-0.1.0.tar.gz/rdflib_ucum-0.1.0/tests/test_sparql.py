"""
Tests for SPARQL integration with CDT quantity types.

Covers native operator support (=, !=, <, >, <=, >=, +, -, *),
ORDER BY with unit-aware sorting, and custom SPARQL functions
(cdt:getValue, cdt:getUnit, cdt:toSI, cdt:sameDimension).

These tests verify that the monkey-patches in sparql_operators.py
and the function registrations in sparql_functions.py work correctly.
"""
import pytest
from rdflib import Graph, Literal, Namespace, XSD

import rdflib_ucum
from rdflib_ucum import CDT

EX = Namespace("http://example.org/")


# -- Shared graph builders --

def _graph_with_three_lengths():
    """Graph with short (500m), medium (1.2km), and long (3km) entities."""
    g = Graph()
    g.bind("cdt", "https://w3id.org/cdt/")
    g.bind("ex", "http://example.org/")
    g.add((EX.short, EX.length, Literal("500 m", datatype=CDT.length)))
    g.add((EX.medium, EX.length, Literal("1.2 km", datatype=CDT.length)))
    g.add((EX.long, EX.length, Literal("3 km", datatype=CDT.length)))
    return g


def _graph_with_equivalent_lengths():
    """Graph with 1 km, 1000 m (equivalent), and 500 m (different)."""
    g = Graph()
    g.bind("cdt", "https://w3id.org/cdt/")
    g.bind("ex", "http://example.org/")
    g.add((EX.a, EX.length, Literal("1 km", datatype=CDT.length)))
    g.add((EX.b, EX.length, Literal("1000 m", datatype=CDT.length)))
    g.add((EX.c, EX.length, Literal("500 m", datatype=CDT.length)))
    return g


class TestSPARQLEquality:
    """FILTER with = and != on CDT literals (works via Literal.eq)."""

    def test_eq_finds_equivalent_units(self):
        """FILTER(?len = '1 km') should match both 1 km AND 1000 m."""
        g = _graph_with_equivalent_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s WHERE {
                ?s ex:length ?len .
                FILTER(?len = "1 km"^^cdt:length)
            }
        '''))
        subjects = {str(row.s) for row in r}
        assert "http://example.org/a" in subjects
        assert "http://example.org/b" in subjects
        assert "http://example.org/c" not in subjects

    def test_neq(self):
        g = _graph_with_equivalent_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s WHERE {
                ?s ex:length ?len .
                FILTER(?len != "1 km"^^cdt:length)
            }
        '''))
        subjects = {str(row.s) for row in r}
        assert "http://example.org/c" in subjects


class TestSPARQLComparison:
    """FILTER with <, >, <=, >= on CDT literals (via monkey-patched operators)."""

    def test_gt(self):
        g = _graph_with_three_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s WHERE {
                ?s ex:length ?len .
                FILTER(?len > "1 km"^^cdt:length)
            }
        '''))
        subjects = {str(row.s) for row in r}
        assert "http://example.org/medium" in subjects
        assert "http://example.org/long" in subjects
        assert "http://example.org/short" not in subjects

    def test_lt(self):
        g = _graph_with_three_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s WHERE {
                ?s ex:length ?len .
                FILTER(?len < "1 km"^^cdt:length)
            }
        '''))
        subjects = {str(row.s) for row in r}
        assert "http://example.org/short" in subjects
        assert len(subjects) == 1

    def test_gte(self):
        g = _graph_with_three_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s WHERE {
                ?s ex:length ?len .
                FILTER(?len >= "1.2 km"^^cdt:length)
            }
        '''))
        subjects = {str(row.s) for row in r}
        assert "http://example.org/medium" in subjects
        assert "http://example.org/long" in subjects

    def test_lte(self):
        g = _graph_with_three_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s WHERE {
                ?s ex:length ?len .
                FILTER(?len <= "1.2 km"^^cdt:length)
            }
        '''))
        subjects = {str(row.s) for row in r}
        assert "http://example.org/short" in subjects
        assert "http://example.org/medium" in subjects


class TestSPARQLArithmetic:
    """BIND with +, -, * on CDT literals (via monkey-patched operators)."""

    def _graph_with_two_lengths(self):
        g = Graph()
        g.bind("cdt", "https://w3id.org/cdt/")
        g.bind("ex", "http://example.org/")
        g.add((EX.obj, EX.len1, Literal("5 km", datatype=CDT.length)))
        g.add((EX.obj, EX.len2, Literal("200 m", datatype=CDT.length)))
        return g

    def test_add(self):
        g = self._graph_with_two_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?total WHERE {
                ?s ex:len1 ?a . ?s ex:len2 ?b .
                BIND(?a + ?b AS ?total)
            }
        '''))
        assert len(r) == 1
        q = r[0].total.toPython()
        assert q.magnitude == pytest.approx(5.2)

    def test_sub(self):
        g = self._graph_with_two_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?diff WHERE {
                ?s ex:len1 ?a . ?s ex:len2 ?b .
                BIND(?a - ?b AS ?diff)
            }
        '''))
        assert len(r) == 1
        q = r[0].diff.toPython()
        assert q.magnitude == pytest.approx(4.8)

    def test_mul_by_scalar(self):
        g = Graph()
        g.bind("cdt", "https://w3id.org/cdt/")
        g.bind("ex", "http://example.org/")
        g.add((EX.obj, EX.len, Literal("5 km", datatype=CDT.length)))
        g.add((EX.obj, EX.factor, Literal(3, datatype=XSD.integer)))

        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?result WHERE {
                ?s ex:len ?a . ?s ex:factor ?f .
                BIND(?a * ?f AS ?result)
            }
        '''))
        assert len(r) == 1
        q = r[0].result.toPython()
        assert q.magnitude == pytest.approx(15)


class TestSPARQLOrderBy:
    """ORDER BY with unit-aware sorting across different units."""

    def test_order_by_asc(self):
        g = _graph_with_three_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s ?len WHERE {
                ?s ex:length ?len .
            } ORDER BY ?len
        '''))
        subjects = [str(row.s) for row in r]
        assert subjects[0].endswith("short")    # 500 m
        assert subjects[1].endswith("medium")   # 1.2 km
        assert subjects[2].endswith("long")     # 3 km

    def test_order_by_desc(self):
        g = _graph_with_three_lengths()
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?s ?len WHERE {
                ?s ex:length ?len .
            } ORDER BY DESC(?len)
        '''))
        subjects = [str(row.s) for row in r]
        assert subjects[0].endswith("long")     # 3 km
        assert subjects[2].endswith("short")    # 500 m


class TestSPARQLFunctions:
    """Custom SPARQL functions: cdt:getValue, cdt:getUnit, cdt:toSI, cdt:sameDimension."""

    def _single_quantity_graph(self):
        g = Graph()
        g.bind("cdt", "https://w3id.org/cdt/")
        g.bind("ex", "http://example.org/")
        g.add((EX.a, EX.length, Literal("1.5 km", datatype=CDT.length)))
        return g


    def test_sameDimension_true(self):
        g = Graph()
        g.bind("cdt", "https://w3id.org/cdt/")
        g.bind("ex", "http://example.org/")
        g.add((EX.a, EX.len1, Literal("1 km", datatype=CDT.length)))
        g.add((EX.a, EX.len2, Literal("500 m", datatype=CDT.length)))
        r = list(g.query('''
            PREFIX cdt: <https://w3id.org/cdt/>
            PREFIX ex: <http://example.org/>
            SELECT ?r WHERE {
                ?s ex:len1 ?a . ?s ex:len2 ?b .
                BIND(cdt:sameDimension(?a, ?b) AS ?r)
            }
        '''))
        assert r[0].r.toPython() is True
