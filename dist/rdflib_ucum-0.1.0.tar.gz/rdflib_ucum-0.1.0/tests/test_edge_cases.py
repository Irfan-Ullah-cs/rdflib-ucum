"""
Tests for edge cases and boundary conditions.

Covers zero quantities, negative values, large magnitudes,
the cdt:ucumunit type, and hash consistency for equivalent quantities.
"""
import rdflib_ucum
from rdflib import Literal
from rdflib_ucum import CDT, UCUMQuantity, UCUMUnit


class TestBoundaryValues:

    def test_zero_quantity(self):
        q = UCUMQuantity(0, "m")
        assert q.magnitude == 0

    def test_negative_quantity(self):
        q = UCUMQuantity(-5, "Cel")
        assert q.magnitude == -5

    def test_large_quantity(self):
        q = UCUMQuantity(3e8, "m/s")
        assert q.magnitude == 3e8


class TestUCUMUnitType:
    """cdt:ucumunit represents a unit without a magnitude."""

    def test_parse_ucumunit_literal(self):
        lit = Literal("km", datatype=CDT.ucumunit)
        u = lit.toPython()
        assert isinstance(u, UCUMUnit)
        assert u.ucum_code == "km"


class TestHashConsistency:
    """Equivalent quantities must produce identical hashes for use in sets/dicts."""

    def test_equivalent_quantities_hash_equal(self):
        a = UCUMQuantity("1 km")
        b = UCUMQuantity("1000 m")
        assert hash(a) == hash(b)
