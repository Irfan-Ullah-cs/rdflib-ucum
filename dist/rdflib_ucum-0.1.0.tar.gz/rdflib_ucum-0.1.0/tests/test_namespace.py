"""
Tests for CDT namespace definitions and datatype registration.

Verifies that all 35 types are registered, URIs are correct,
and the is_cdt_datatype() helper works as expected.
"""
from rdflib import XSD

import rdflib_ucum
from rdflib_ucum import CDT
from rdflib_ucum.namespace import is_cdt_datatype, ALL_CDT_TYPES, ALL_QUANTITY_TYPES


class TestNamespaceRegistration:

    def test_all_35_types_registered(self):
        assert len(ALL_CDT_TYPES) == 35

    def test_all_33_quantity_types(self):
        assert len(ALL_QUANTITY_TYPES) == 33

    def test_is_cdt_datatype_positive(self):
        assert is_cdt_datatype(CDT.length)
        assert is_cdt_datatype(CDT.mass)
        assert is_cdt_datatype(CDT.ucum)

    def test_is_cdt_datatype_negative(self):
        assert not is_cdt_datatype(XSD.integer)
        assert not is_cdt_datatype(None)

    def test_cdt_namespace_uri(self):
        assert str(CDT.length) == "https://w3id.org/cdt/length"
