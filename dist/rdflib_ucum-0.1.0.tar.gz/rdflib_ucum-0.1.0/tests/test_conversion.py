"""
Tests for unit conversion methods on UCUMQuantity.

Covers converting between compatible units, converting to SI base units,
and checking whether two quantities share the same physical dimension.
"""
import pytest

import rdflib_ucum
from rdflib_ucum import UCUMQuantity


class TestUnitConversion:

    def test_to_meters(self):
        q = UCUMQuantity("1.5 km")
        r = q.to("m")
        assert r.magnitude == pytest.approx(1500)
        assert r.ucum_unit == "m"

    def test_to_si(self):
        q = UCUMQuantity("1.5 km")
        r = q.to_si()
        assert r.magnitude == pytest.approx(1500)

    def test_same_dimension_compatible(self):
        a = UCUMQuantity("1 km")
        b = UCUMQuantity("500 m")
        assert a.same_dimension(b)

    def test_same_dimension_incompatible(self):
        a = UCUMQuantity("1 km")
        b = UCUMQuantity("1 kg")
        assert not a.same_dimension(b)
