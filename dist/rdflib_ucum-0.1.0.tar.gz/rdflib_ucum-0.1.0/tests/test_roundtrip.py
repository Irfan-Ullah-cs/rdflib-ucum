"""
Tests for serialization round-trips through Turtle and N-Triples formats.

Verifies that CDT quantity literals survive serialization and parsing
with their datatype URI, lexical form, and parsed value intact.
"""
import pytest
from rdflib import Graph, Literal, Namespace

import rdflib_ucum
from rdflib_ucum import CDT, UCUMQuantity

EX = Namespace("http://example.org/")


class TestTurtleRoundTrip:

    def test_turtle_roundtrip(self):
        g = Graph()
        g.bind("cdt", "https://w3id.org/cdt/")
        g.bind("ex", "http://example.org/")
        g.add((EX.bridge, EX.length, Literal("1.2 km", datatype=CDT.length)))

        ttl = g.serialize(format="turtle")
        assert "1.2 km" in ttl
        assert "cdt:length" in ttl

        g2 = Graph()
        g2.parse(data=ttl, format="turtle")
        lit = list(g2.objects(EX.bridge, EX.length))[0]
        assert isinstance(lit, Literal)
        q = lit.toPython()
        assert isinstance(q, UCUMQuantity)
        assert q.magnitude == pytest.approx(1.2)
        assert q.ucum_unit == "km"


class TestNTriplesRoundTrip:

    def test_ntriples_roundtrip(self):
        g = Graph()
        g.add((EX.obj, EX.mass, Literal("75 kg", datatype=CDT.mass)))
        nt = g.serialize(format="nt")
        g2 = Graph()
        g2.parse(data=nt, format="nt")
        lit = list(g2.objects(EX.obj, EX.mass))[0]
        assert lit.toPython().magnitude == pytest.approx(75)
