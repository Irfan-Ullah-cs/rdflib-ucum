"""
UCUM ↔ Pint unit translation layer.

Provides the shared Pint UnitRegistry singleton, the UCUM-to-Pint mapping
table, and parsing/serialization helpers used by both UCUMQuantity and UCUMUnit.

This module is a pure data + utility layer with no RDFLib dependency.
"""
from __future__ import annotations

import re
from functools import lru_cache

import pint

# ---------------------------------------------------------------------------
# Singleton Pint UnitRegistry
# ---------------------------------------------------------------------------
_ureg: pint.UnitRegistry | None = None


def get_ureg() -> pint.UnitRegistry:
    """Return the shared PintUcumRegistry (or plain UnitRegistry as fallback)."""
    global _ureg
    if _ureg is None:
        try:
            from ucumvert import PintUcumRegistry  # type: ignore[import-untyped]
            _ureg = PintUcumRegistry()
        except ImportError:
            _ureg = pint.UnitRegistry()
    return _ureg


# ---------------------------------------------------------------------------
# UCUM → Pint mapping for common units  (used when ucumvert is absent)
# ---------------------------------------------------------------------------
UCUM_TO_PINT: dict[str, str] = {
    # Length
    "m": "meter", "km": "kilometer", "cm": "centimeter", "mm": "millimeter",
    "um": "micrometer", "nm": "nanometer", "mi_i": "mile", "ft_i": "foot",
    "in_i": "inch", "yd_i": "yard", "[nmi_i]": "nautical_mile",
    # Mass
    "kg": "kilogram", "g": "gram", "mg": "milligram", "ug": "microgram",
    "t": "metric_ton", "[lb_av]": "pound", "[oz_av]": "ounce",
    # Time
    "s": "second", "ms": "millisecond", "us": "microsecond", "ns": "nanosecond",
    "min": "minute", "h": "hour", "d": "day", "wk": "week", "a": "year",
    # Temperature
    "K": "kelvin", "Cel": "degC", "[degF]": "degF",
    # Speed
    "m/s": "meter/second", "km/h": "kilometer/hour",
    # Acceleration
    "m/s2": "meter/second**2",
    # Force
    "N": "newton", "kN": "kilonewton",
    # Energy
    "J": "joule", "kJ": "kilojoule", "MJ": "megajoule",
    "cal": "calorie", "kcal": "kilocalorie", "eV": "electron_volt",
    # Power
    "W": "watt", "kW": "kilowatt", "MW": "megawatt",
    # Pressure
    "Pa": "pascal", "kPa": "kilopascal", "MPa": "megapascal",
    "bar": "bar", "mbar": "millibar", "atm": "atmosphere",
    # Electric
    "A": "ampere", "mA": "milliampere",
    "V": "volt", "kV": "kilovolt", "mV": "millivolt",
    "Ohm": "ohm", "kOhm": "kiloohm", "MOhm": "megaohm",
    "F": "farad", "uF": "microfarad", "nF": "nanofarad", "pF": "picofarad",
    "S": "siemens", "mS": "millisiemens",
    "H": "henry", "mH": "millihenry",
    "C": "coulomb",
    "Wb": "weber", "T": "tesla",
    # Frequency
    "Hz": "hertz", "kHz": "kilohertz", "MHz": "megahertz", "GHz": "gigahertz",
    # Area & Volume
    "m2": "meter**2", "cm2": "centimeter**2", "km2": "kilometer**2",
    "m3": "meter**3", "L": "liter", "mL": "milliliter", "dL": "deciliter",
    # Angle
    "rad": "radian", "deg": "degree", "sr": "steradian",
    # Amount of substance
    "mol": "mole", "mmol": "millimole",
    # Luminous
    "cd": "candela", "lm": "lumen", "lx": "lux",
    # Radioactivity / Radiation
    "Bq": "becquerel", "Gy": "gray", "Sv": "sievert",
    # Catalytic activity
    "kat": "katal",
    # Dimensionless
    "1": "dimensionless", "%": "percent",
}

# Reverse mapping: Pint unit string → UCUM code
PINT_TO_UCUM: dict[str, str] = {v: k for k, v in UCUM_TO_PINT.items()}

# Regex to split "1.2 km" → ("1.2", "km")
LEXICAL_RE = re.compile(
    r"^\s*([+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?)\s+(.+)\s*$"
)


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def ucum_to_pint_unit(ucum_code: str) -> pint.Unit:
    """Convert a UCUM unit code to a pint Unit."""
    ureg = get_ureg()

    # 1) Try ucumvert's native parsing (if available)
    if hasattr(ureg, "from_ucum"):
        try:
            return ureg.from_ucum(f"1 {ucum_code}").units
        except Exception:
            pass

    # 2) Direct lookup in mapping table
    if ucum_code in UCUM_TO_PINT:
        return ureg.parse_units(UCUM_TO_PINT[ucum_code])

    # 3) Handle compound units like "kg.m/s2" → "kg*m/s**2"
    pint_str = ucum_code.replace(".", "*")
    pint_str = re.sub(r"(\w)(\d)$", r"\1**\2", pint_str)
    pint_str = re.sub(r"(\w)(\d)([/*])", r"\1**\2\3", pint_str)
    try:
        return ureg.parse_units(pint_str)
    except Exception:
        pass

    # 4) Last resort — let Pint try directly
    return ureg.parse_units(ucum_code)


@lru_cache(maxsize=512)
def cached_parse_unit(ucum_code: str) -> pint.Unit:
    """Cached version of :func:`ucum_to_pint_unit` for performance."""
    return ucum_to_pint_unit(ucum_code)


def pint_unit_to_ucum(unit: pint.Unit) -> str:
    """Best-effort conversion of a Pint Unit back to a UCUM code string."""
    unit_str = str(unit)
    if unit_str in PINT_TO_UCUM:
        return PINT_TO_UCUM[unit_str]
    # Compact format — convert pint format back to UCUM-ish
    result = unit_str
    result = result.replace(" * ", ".")
    result = result.replace(" / ", "/")
    result = re.sub(r"\*\*(\d+)", r"\1", result)
    for pint_name, ucum_code in PINT_TO_UCUM.items():
        result = result.replace(pint_name, ucum_code)
    return result
